(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/app/escape/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>EscapePage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/config.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
const STAGES = [
    {
        title: "Stage 1: Hello, World!",
        prompt: 'Write JavaScript code that prints "Hello world" to the console.',
        hint: `Use console.log("Hello world");`
    },
    {
        title: "Stage 2: Alert Message",
        prompt: 'Write JavaScript code that shows an alert popup with the text "Welcome to the escape room!"',
        hint: `Use alert("Welcome to the escape room!");`
    },
    {
        title: "Stage 3: Make a Function!!!!",
        prompt: "Write a JavaScript function named add(a, b) that returns the sum of its two arguments, and then call it once.",
        hint: `Example shape: function add(a, b) { return a + b; }`
    }
];
function formatTime(totalSeconds) {
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;
}
function formatDateTime(iso) {
    const d = new Date(iso);
    return d.toLocaleString();
}
function validateAnswer(stageIndex, answer) {
    const lower = answer.toLowerCase();
    switch(stageIndex){
        case 0:
            return lower.includes("console.log") && lower.includes("hello world");
        case 1:
            return lower.includes("alert(");
        case 2:
            return lower.includes("function") && lower.includes("add") && lower.includes("return");
        default:
            return answer.trim().length > 0;
    }
}
function EscapePage() {
    _s();
    const [gameStarted, setGameStarted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [finished, setFinished] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [elapsedSeconds, setElapsedSeconds] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [currentStageIndex, setCurrentStageIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [currentAnswer, setCurrentAnswer] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [feedback, setFeedback] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [leaderboard, setLeaderboard] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [leaderboardLoading, setLeaderboardLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [leaderboardError, setLeaderboardError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [showGiveUpConfirm, setShowGiveUpConfirm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [saveStatus, setSaveStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("idle");
    // note edit/delete UI state
    const [editingId, setEditingId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [editingNote, setEditingNote] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [noteSavingId, setNoteSavingId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [deletingId, setDeletingId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // reset everything back to the intro state
    const resetGameToStart = ()=>{
        setGameStarted(false);
        setFinished(false);
        setElapsedSeconds(0);
        setCurrentStageIndex(0);
        setCurrentAnswer("");
        setFeedback(null);
        setShowGiveUpConfirm(false);
        setSaveStatus("idle");
    };
    // load leaderboard from API
    async function loadLeaderboard() {
        try {
            setLeaderboardLoading(true);
            setLeaderboardError(null);
            const res = await fetch("/api/escape-time", {
                method: "GET"
            });
            if (!res.ok) {
                throw new Error("Failed to fetch leaderboard");
            }
            const data = await res.json();
            setLeaderboard(data.records ?? []);
        } catch (err) {
            console.error("Error loading leaderboard:", err);
            setLeaderboardError("Failed to load leaderboard.");
        } finally{
            setLeaderboardLoading(false);
        }
    }
    // load leaderboard on initial mount
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "EscapePage.useEffect": ()=>{
            loadLeaderboard();
        }
    }["EscapePage.useEffect"], []);
    // count up timer
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "EscapePage.useEffect": ()=>{
            if (!gameStarted || finished) return;
            const interval = setInterval({
                "EscapePage.useEffect.interval": ()=>{
                    setElapsedSeconds({
                        "EscapePage.useEffect.interval": (prev)=>prev + 1
                    }["EscapePage.useEffect.interval"]);
                }
            }["EscapePage.useEffect.interval"], 1000);
            return ({
                "EscapePage.useEffect": ()=>clearInterval(interval)
            })["EscapePage.useEffect"];
        }
    }["EscapePage.useEffect"], [
        gameStarted,
        finished
    ]);
    const handleEnter = ()=>{
        setGameStarted(true);
        setFinished(false);
        setCurrentStageIndex(0);
        setElapsedSeconds(0); // start from 0 sec
        setCurrentAnswer("");
        setFeedback(null);
        setShowGiveUpConfirm(false);
        setSaveStatus("idle");
    };
    const handleSubmitAnswer = ()=>{
        const ok = validateAnswer(currentStageIndex, currentAnswer);
        if (!ok) {
            setFeedback("Not quite right yet.... Try again!");
            return;
        }
        const isLastStage = currentStageIndex === STAGES.length - 1;
        if (isLastStage) {
            setFinished(true);
            setGameStarted(false);
            setFeedback("Nice! You cleared all stages");
            setShowGiveUpConfirm(false);
        } else {
            setCurrentStageIndex((prev)=>prev + 1);
            setCurrentAnswer("");
            setFeedback("Nice! Moving to the next stage...");
        }
    };
    const handleSaveTime = async ()=>{
        // prevent double-save
        if (saveStatus === "saving" || saveStatus === "saved") return;
        const timeTakenSeconds = elapsedSeconds;
        setSaveStatus("saving");
        try {
            const res = await fetch("/api/escape-time", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    timeSeconds: timeTakenSeconds,
                    studentId: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studentInfo"].number,
                    studentFirstName: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studentInfo"].firstname
                })
            });
            if (!res.ok) {
                const data = await res.json().catch(()=>({}));
                console.error("Save failed:", data);
                setSaveStatus("error");
                setTimeout(()=>setSaveStatus("idle"), 3000);
                return;
            }
            const data = await res.json();
            console.log("Saved escape time record:", data.record);
            await loadLeaderboard();
            setSaveStatus("saved");
        } catch (err) {
            console.error("Network error saving time:", err);
            setSaveStatus("error");
            setTimeout(()=>setSaveStatus("idle"), 3000);
        }
    };
    const handleBackToStart = ()=>{
        resetGameToStart();
    };
    const handleConfirmGiveUp = ()=>{
        // "Yeah..." confirmation on chickenout
        resetGameToStart(); // nothing is saved
    };
    // --- Note editing handlers ---
    const startEditNote = (entry)=>{
        // only allow editing "my" scores (same studentId)
        if (entry.studentId && entry.studentId !== __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studentInfo"].number) return;
        setEditingId(entry.id);
        setEditingNote(entry.note ?? "");
    };
    const cancelEditNote = ()=>{
        setEditingId(null);
        setEditingNote("");
        setNoteSavingId(null);
    };
    const handleSaveNote = async ()=>{
        if (!editingId) return;
        const trimmed = editingNote.trim();
        setNoteSavingId(editingId);
        try {
            const res = await fetch(`/api/escape-time/${editingId}`, {
                method: "PATCH",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    note: trimmed.length > 0 ? trimmed : null
                })
            });
            if (!res.ok) {
                console.error("Failed to update note");
                setNoteSavingId(null);
                return;
            }
            const data = await res.json();
            setLeaderboard((prev)=>prev.map((entry)=>entry.id === data.record.id ? data.record : entry));
            cancelEditNote();
        } catch (error) {
            console.error("Error updating note:", error);
            setNoteSavingId(null);
        }
    };
    // --- Delete handler ---
    const handleDeleteEntry = async (entry)=>{
        // only allow deleting "my" scores
        if (entry.studentId && entry.studentId !== __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studentInfo"].number) return;
        setDeletingId(entry.id);
        try {
            const res = await fetch(`/api/escape-time/${entry.id}`, {
                method: "DELETE"
            });
            if (!res.ok) {
                console.error("Failed to delete record");
                setDeletingId(null);
                return;
            }
            setLeaderboard((prev)=>prev.filter((e)=>e.id !== entry.id));
            if (editingId === entry.id) {
                cancelEditNote();
            }
            setDeletingId(null);
        } catch (error) {
            console.error("Error deleting record:", error);
            setDeletingId(null);
        }
    };
    const timeTaken = elapsedSeconds;
    const currentStage = STAGES[currentStageIndex];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "-mx-4 md:-mx-6 lg:-mx-8 -my-6",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "relative min-h-[70vh] md:min-h-[calc(103vh-160px)] flex items-center justify-center",
            style: {
                backgroundImage: 'url("/bg.jpg")',
                backgroundSize: "cover",
                backgroundPosition: "center"
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "absolute inset-0 bg-black/50"
                }, void 0, false, {
                    fileName: "[project]/src/app/escape/page.tsx",
                    lineNumber: 326,
                    columnNumber: 9
                }, this),
                (gameStarted || finished) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "absolute top-4 right-4 z-20",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "rounded-full px-4 py-2 bg-black/70 text-white text-sm font-mono flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "font-semibold",
                                children: finished ? "Final time:" : "Time:"
                            }, void 0, false, {
                                fileName: "[project]/src/app/escape/page.tsx",
                                lineNumber: 332,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: formatTime(elapsedSeconds)
                            }, void 0, false, {
                                fileName: "[project]/src/app/escape/page.tsx",
                                lineNumber: 335,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/escape/page.tsx",
                        lineNumber: 331,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/escape/page.tsx",
                    lineNumber: 330,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "relative z-10 max-w-4xl w-full px-4 py-8",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col md:flex-row gap-6 items-stretch",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex-1",
                                children: [
                                    !gameStarted && !finished && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-center md:text-left bg-white/90 dark:bg-gray-900/90 rounded-2xl shadow-xl px-6 py-10",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                                className: "text-3xl md:text-4xl font-extrabold mb-6 text-gray-900 dark:text-white",
                                                children: "Welcome to the escape room!!"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/escape/page.tsx",
                                                lineNumber: 348,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-sm md:text-base text-gray-700 dark:text-gray-300 mb-6",
                                                children: "We'll track how long you take to solve three JS challenges. Can you really escape this? Run as fast as you can!"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/escape/page.tsx",
                                                lineNumber: 351,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: handleEnter,
                                                className: "mt-2 inline-flex items-center justify-center px-5 py-2.5 rounded-md text-lg font-semibold    bg-green-500 hover:bg-green-600 text-white shadow-lg transition-colors gap-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                        src: "/enter.svg",
                                                        alt: "Enter button icon",
                                                        width: 20,
                                                        height: 20,
                                                        className: "w-5 h-5 -ml-1"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/escape/page.tsx",
                                                        lineNumber: 361,
                                                        columnNumber: 21
                                                    }, this),
                                                    "Enter"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/escape/page.tsx",
                                                lineNumber: 356,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/escape/page.tsx",
                                        lineNumber: 347,
                                        columnNumber: 17
                                    }, this),
                                    gameStarted && !finished && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "bg-white/95 dark:bg-gray-900/95 rounded-2xl shadow-xl px-6 py-8 space-y-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex justify-between items-center mb-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                        className: "text-xl md:text-2xl font-bold text-gray-900 dark:text-white",
                                                        children: currentStage.title
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/escape/page.tsx",
                                                        lineNumber: 377,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-xs md:text-sm text-gray-600 dark:text-gray-400",
                                                        children: [
                                                            "Stage ",
                                                            currentStageIndex + 1,
                                                            " of ",
                                                            STAGES.length
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/escape/page.tsx",
                                                        lineNumber: 380,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/escape/page.tsx",
                                                lineNumber: 376,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-sm md:text-base text-gray-800 dark:text-gray-200",
                                                children: currentStage.prompt
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/escape/page.tsx",
                                                lineNumber: 385,
                                                columnNumber: 19
                                            }, this),
                                            currentStage.hint && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-xs md:text-sm text-gray-600 dark:text-gray-400 italic",
                                                children: [
                                                    "Hint: ",
                                                    currentStage.hint
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/escape/page.tsx",
                                                lineNumber: 390,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                                value: currentAnswer,
                                                onChange: (e)=>setCurrentAnswer(e.target.value),
                                                placeholder: "Type your JavaScript code here...",
                                                className: "mt-3 w-full min-h-[180px] rounded-lg border border-gray-300 dark:border-gray-700    bg-gray-50 dark:bg-[#111827] text-sm md:text-base    font-mono text-gray-900 dark:text-gray-100 p-3 focus:outline-none    focus:ring-2 focus:ring-green-500"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/escape/page.tsx",
                                                lineNumber: 395,
                                                columnNumber: 19
                                            }, this),
                                            feedback && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-sm mt-2 text-green-700 dark:text-green-300",
                                                children: feedback
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/escape/page.tsx",
                                                lineNumber: 406,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex justify-between items-center mt-4",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        type: "button",
                                                        onClick: ()=>setShowGiveUpConfirm(true),
                                                        className: "inline-flex items-center justify-center px-4 py-2.5 rounded-md text-xs md:text-sm font-semibold    bg-gray-500 hover:bg-gray-600 text-white shadow-sm transition-colors",
                                                        children: "Chicken out"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/escape/page.tsx",
                                                        lineNumber: 413,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        onClick: handleSubmitAnswer,
                                                        className: "inline-flex items-center justify-center px-6 py-2.5 rounded-md text-sm md:text-base font-semibold    bg-green-500 hover:bg-green-600 text-white shadow-md transition-colors",
                                                        children: "Submit Answer"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/escape/page.tsx",
                                                        lineNumber: 421,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/escape/page.tsx",
                                                lineNumber: 412,
                                                columnNumber: 19
                                            }, this),
                                            showGiveUpConfirm && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "mt-4 rounded-lg border border-red-300 dark:border-red-700 bg-red-50 dark:bg-red-900/40 px-4 py-3 text-sm",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-red-800 dark:text-red-100 mb-3",
                                                        children: "Are you sure you wish to give up?"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/escape/page.tsx",
                                                        lineNumber: 433,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex justify-end gap-3",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                type: "button",
                                                                onClick: ()=>setShowGiveUpConfirm(false),
                                                                className: "inline-flex items-center justify-center px-4 py-2 rounded-md text-xs md:text-sm font-semibold    bg-gray-500 hover:bg-gray-600 text-white shadow-sm transition-colors",
                                                                children: "No!"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/escape/page.tsx",
                                                                lineNumber: 437,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                type: "button",
                                                                onClick: handleConfirmGiveUp,
                                                                className: "inline-flex items-center justify-center px-4 py-2 rounded-md text-xs md:text-sm font-semibold    bg-red-600 hover:bg-red-700 text-white shadow-sm transition-colors",
                                                                children: "Yeah..."
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/escape/page.tsx",
                                                                lineNumber: 445,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/escape/page.tsx",
                                                        lineNumber: 436,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/escape/page.tsx",
                                                lineNumber: 432,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/escape/page.tsx",
                                        lineNumber: 375,
                                        columnNumber: 17
                                    }, this),
                                    finished && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-center bg-white/90 dark:bg-gray-900/90 rounded-2xl shadow-xl px-6 py-10 space-y-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                className: "text-2xl md:text-3xl font-bold text-gray-900 dark:text-white",
                                                children: "Congratulations!"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/escape/page.tsx",
                                                lineNumber: 462,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-sm md:text-base text-gray-700 dark:text-gray-300",
                                                children: "You successfully escaped by completing all three JavaScript challenges."
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/escape/page.tsx",
                                                lineNumber: 465,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-sm md:text-base text-gray-700 dark:text-gray-300",
                                                children: [
                                                    "Your time:",
                                                    " ",
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "font-mono font-semibold",
                                                        children: formatTime(timeTaken)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/escape/page.tsx",
                                                        lineNumber: 471,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/escape/page.tsx",
                                                lineNumber: 469,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "mt-4 flex flex-col sm:flex-row justify-center gap-3",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        onClick: handleBackToStart,
                                                        className: "inline-flex items-center justify-center px-6 py-2.5 rounded-md text-sm md:text-base font-semibold    bg-gray-500 hover:bg-gray-600 text-white shadow-md transition-colors",
                                                        children: "Back to start"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/escape/page.tsx",
                                                        lineNumber: 476,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        onClick: handleSaveTime,
                                                        disabled: saveStatus === "saving" || saveStatus === "saved",
                                                        className: `inline-flex items-center justify-center px-8 py-3 rounded-md text-sm md:text-base font-semibold shadow-lg transition-colors
                        ${saveStatus === "saved" ? "bg-gray-500 hover:bg-gray-500 cursor-default text-white" : "bg-green-500 hover:bg-green-600 text-white"}
                        ${saveStatus === "saving" ? "opacity-80 cursor-wait" : ""}
                      `,
                                                        children: saveStatus === "saving" ? "Saving..." : saveStatus === "saved" ? "Saved!" : saveStatus === "error" ? "Save failed.." : "Save Time"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/escape/page.tsx",
                                                        lineNumber: 483,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/escape/page.tsx",
                                                lineNumber: 475,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/escape/page.tsx",
                                        lineNumber: 461,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/escape/page.tsx",
                                lineNumber: 344,
                                columnNumber: 13
                            }, this),
                            !gameStarted && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "md:w-72 bg-white/90 dark:bg-gray-900/90 rounded-2xl shadow-xl px-4 py-6",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-2 mb-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                src: "/trophy.svg",
                                                alt: "Trophy",
                                                className: "w-5 h-5"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/escape/page.tsx",
                                                lineNumber: 516,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                className: "text-lg font-semibold text-gray-900 dark:text-white",
                                                children: "Leaderboard"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/escape/page.tsx",
                                                lineNumber: 517,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/escape/page.tsx",
                                        lineNumber: 515,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-xs text-gray-600 dark:text-gray-400 mb-3",
                                        children: "Top 5 fastest escape times."
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/escape/page.tsx",
                                        lineNumber: 522,
                                        columnNumber: 17
                                    }, this),
                                    leaderboardLoading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-xs text-gray-600 dark:text-gray-400",
                                        children: "Loading..."
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/escape/page.tsx",
                                        lineNumber: 527,
                                        columnNumber: 19
                                    }, this),
                                    leaderboardError && !leaderboardLoading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-xs text-red-500",
                                        children: leaderboardError
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/escape/page.tsx",
                                        lineNumber: 533,
                                        columnNumber: 19
                                    }, this),
                                    !leaderboardLoading && !leaderboardError && leaderboard.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-xs text-gray-600 dark:text-gray-400",
                                        children: "No completions yet."
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/escape/page.tsx",
                                        lineNumber: 539,
                                        columnNumber: 21
                                    }, this),
                                    !leaderboardLoading && !leaderboardError && leaderboard.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                                        className: "mt-2 space-y-2 text-xs",
                                        children: leaderboard.map((entry, index)=>{
                                            const isMine = entry.studentId === __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studentInfo"].number || !entry.studentId; // fallback if null in DB
                                            const isEditing = editingId === entry.id;
                                            const isSavingThisNote = noteSavingId === entry.id;
                                            const isDeletingThis = deletingId === entry.id;
                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                className: "flex flex-col rounded-md bg-gray-100/80 dark:bg-gray-800/80 px-3 py-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-start justify-between gap-2",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex-1",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "font-semibold text-gray-900 dark:text-gray-100",
                                                                        children: [
                                                                            "#",
                                                                            index + 1,
                                                                            " ·",
                                                                            " ",
                                                                            entry.studentFirstName ?? "Anonymous",
                                                                            " ·",
                                                                            " ",
                                                                            entry.timeSeconds,
                                                                            "s"
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/app/escape/page.tsx",
                                                                        lineNumber: 564,
                                                                        columnNumber: 33
                                                                    }, this),
                                                                    entry.note && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "mt-0.5 text-[0.7rem] text-gray-700 dark:text-gray-300",
                                                                        children: [
                                                                            "Note: ",
                                                                            entry.note
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/app/escape/page.tsx",
                                                                        lineNumber: 570,
                                                                        columnNumber: 35
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-[0.7rem] text-gray-600 dark:text-gray-400",
                                                                        children: formatDateTime(entry.createdAt)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/escape/page.tsx",
                                                                        lineNumber: 574,
                                                                        columnNumber: 33
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/escape/page.tsx",
                                                                lineNumber: 563,
                                                                columnNumber: 31
                                                            }, this),
                                                            isMine && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex items-center gap-2 text-base",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                        type: "button",
                                                                        onClick: ()=>startEditNote(entry),
                                                                        disabled: isDeletingThis,
                                                                        className: `leading-none ${isDeletingThis ? "opacity-50 cursor-not-allowed" : "hover:opacity-80"}`,
                                                                        "aria-label": "Edit note",
                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                            src: "/edit.svg",
                                                                            alt: "Edit note",
                                                                            width: 16,
                                                                            height: 16,
                                                                            className: "w-4 h-4"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/escape/page.tsx",
                                                                            lineNumber: 591,
                                                                            columnNumber: 39
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/escape/page.tsx",
                                                                        lineNumber: 582,
                                                                        columnNumber: 37
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                        type: "button",
                                                                        onClick: ()=>handleDeleteEntry(entry),
                                                                        disabled: isDeletingThis,
                                                                        className: `leading-none ${isDeletingThis ? "opacity-50 cursor-not-allowed" : "hover:opacity-80"}`,
                                                                        "aria-label": "Delete record",
                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                            src: "/delete.svg",
                                                                            alt: "Delete record",
                                                                            width: 16,
                                                                            height: 16,
                                                                            className: "w-4 h-4"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/escape/page.tsx",
                                                                            lineNumber: 609,
                                                                            columnNumber: 39
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/escape/page.tsx",
                                                                        lineNumber: 600,
                                                                        columnNumber: 37
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/escape/page.tsx",
                                                                lineNumber: 581,
                                                                columnNumber: 35
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/escape/page.tsx",
                                                        lineNumber: 562,
                                                        columnNumber: 29
                                                    }, this),
                                                    isEditing && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "mt-2 flex items-center gap-2",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                type: "text",
                                                                value: editingNote,
                                                                onChange: (e)=>setEditingNote(e.target.value),
                                                                className: "flex-1 rounded border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 px-2 py-1 text-[0.7rem] text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-1 focus:ring-green-500",
                                                                placeholder: "Add a note for this run..."
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/escape/page.tsx",
                                                                lineNumber: 626,
                                                                columnNumber: 33
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                type: "button",
                                                                onClick: handleSaveNote,
                                                                disabled: isSavingThisNote,
                                                                className: `px-2 py-1 rounded text-[0.7rem] font-semibold ${isSavingThisNote ? "bg-green-400 text-white cursor-wait" : "bg-green-500 hover:bg-green-600 text-white"}`,
                                                                children: isSavingThisNote ? "Saving..." : "Save"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/escape/page.tsx",
                                                                lineNumber: 635,
                                                                columnNumber: 33
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                type: "button",
                                                                onClick: cancelEditNote,
                                                                disabled: isSavingThisNote,
                                                                className: "px-2 py-1 rounded text-[0.7rem] font-semibold bg-gray-300 hover:bg-gray-400 text-gray-800",
                                                                children: "X"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/escape/page.tsx",
                                                                lineNumber: 647,
                                                                columnNumber: 33
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/escape/page.tsx",
                                                        lineNumber: 625,
                                                        columnNumber: 31
                                                    }, this)
                                                ]
                                            }, entry.id, true, {
                                                fileName: "[project]/src/app/escape/page.tsx",
                                                lineNumber: 558,
                                                columnNumber: 27
                                            }, this);
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/escape/page.tsx",
                                        lineNumber: 547,
                                        columnNumber: 21
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/escape/page.tsx",
                                lineNumber: 514,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/escape/page.tsx",
                        lineNumber: 342,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/escape/page.tsx",
                    lineNumber: 341,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/escape/page.tsx",
            lineNumber: 317,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/escape/page.tsx",
        lineNumber: 316,
        columnNumber: 5
    }, this);
}
_s(EscapePage, "6ojlXe2pCYGyuUijvb4kgw8ivS0=");
_c = EscapePage;
var _c;
__turbopack_context__.k.register(_c, "EscapePage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_app_escape_page_tsx_90ef3598._.js.map